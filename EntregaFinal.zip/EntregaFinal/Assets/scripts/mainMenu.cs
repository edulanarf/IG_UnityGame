using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public class mainMenu : MonoBehaviour
{
    public void StartGame()
    {
        SceneManager.LoadScene("chooseCharacter");
    }

    public void ExitGame()
    {
        Application.Quit();
        #if UNITY_EDITOR
                EditorApplication.isPlaying = false;
        #endif
    }

    public void BackToMainMenu()
    {
        SceneManager.LoadScene("Menu");
    }
    public void BackToChampionSelect()
    {
        SceneManager.LoadScene("chooseCharacter");
    }
}
