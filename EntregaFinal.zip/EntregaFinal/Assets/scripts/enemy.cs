using System;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;
using System.Collections;

public class enemy : MonoBehaviour
{
    public float speed = 2f;
    private Transform player;

    public float damageInterval = 1f;
    private float lastDamageTime;

    private int maxHp = 100;
    private int currentHp;

    private Camera mainCamera;

    public GameObject damagePopup;

    public GameObject coin;

    public Animator animator;

    bool isAlive = true;


    void Start()
    {
        currentHp = maxHp;
        player = GameObject.FindWithTag("Player").transform;
        lastDamageTime = -damageInterval;
        mainCamera = Camera.main;
    }

    void Update()
    {
        if (player != null)
        {
            if (isAlive)
            {
                Vector2 direction = (player.position - transform.position).normalized;
                transform.position += (Vector3)direction * speed * Time.deltaTime;
            }

            // Girar enemigo segun direcci�n del player
                if (player.position.x > transform.position.x)
                    transform.localScale = new Vector3(3, 3, 1);
                else
                    transform.localScale = new Vector3(-3, 3, 1);
        }
    }

    void OnCollisionStay2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            if (Time.time - lastDamageTime >= damageInterval)
            {
                if (isAlive) //Este if lo hago debido a que necesito que se ejecute la animacion antes de destruir el objeto "enemy" y a veces mientras se
                             //hac�a la animaci�n, si te acercabas el enemigo segu�a atacando...
                {
                    gameManager.Instance.damage(10); //TODO Cambiar mas adelante para diferentes tipos de enemigos
                    lastDamageTime = Time.time;
                    AttackPlayer(); //Esto lo hago para hacer la animacion
                }
            }
        }
    }
    void AttackPlayer()
    {
        animator.SetTrigger("Attack");
    }

    void DestroyEnemy()
    {
        animator.SetTrigger("Die");
        isAlive = false;
        GetComponent<Collider2D>().enabled = false;
        StartCoroutine(DestroyAfterDelay(1f));
    }

    IEnumerator DestroyAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        Destroy(gameObject);
        GameObject enemyCoins = Instantiate(coin, transform.position, Quaternion.identity); //Instancio una moneda al morir el enemy
    }


    public void damageEnemy(int damage)
    {
        bool isCrit= false;
        int crit = gameManager.Instance.critProb;
        int damagePercent = gameManager.Instance.damagePercent;
        int damageDone = Mathf.CeilToInt(damage * (1 + gameManager.Instance.damagePercent / 100f));
        if (UnityEngine.Random.Range(0f, 100f) < crit)
        {
            isCrit = true;
            damageDone *= 2;
        }

        currentHp -= damageDone;
        gameManager.Instance.healLifeSteal(damageDone);
        

        GameObject popup = Instantiate(damagePopup, transform.position, Quaternion.identity);
        popup.GetComponent<damagePopup>().Setup(damageDone, isCrit);

        if (currentHp <= 0)
        {
            DestroyEnemy();
        }
    }

}
