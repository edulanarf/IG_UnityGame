using UnityEngine;

public class weaponDataHolder : MonoBehaviour
{
    public static GameObject selectedWeaponPrefab;
}
