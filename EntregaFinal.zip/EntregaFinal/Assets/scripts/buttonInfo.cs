using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.TextCore.Text;

public class buttonInfo : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public characterBase character;

    private int labelWidth = 14;

    private string PadLabel(string label)
    {
        return label.PadRight(labelWidth);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        string tooltipMessage =
            $"    {PadLabel("Name:")} {character.characterName}\n" +
            $"<sprite=6> {PadLabel("Health:")} {character.maxHealth}\n" +
            $"<sprite=2> {PadLabel("HP Regen:")} {character.healthRecovery}\n" +
            $"<sprite=4> {PadLabel("LifeSteal:")} {character.lifeSteal}\n" +
            $"<sprite=21> {PadLabel("Damage:")} {character.damage}\n" +
            $"<sprite=8> {PadLabel("Melee DMG:")} {character.meleeDamage}\n" +
            $"<sprite=7> {PadLabel("Range DMG:")} {character.rangeDamage}\n" +
            $"<sprite=3> {PadLabel("Elem DMG:")} {character.elementalDamage}\n" +
            $"<sprite=15> {PadLabel("Atk Spd:")} {character.attackSpeed}\n" +
            $"<sprite=11> {PadLabel("Crit:")} {character.crit}\n" +
            $"<sprite=14> {PadLabel("Range:")} {character.range}\n" +
            $"<sprite=23> {PadLabel("Agility:")} {character.agility}\n" +
            $"<sprite=9> {PadLabel("Speed:")} {character.speed}";

        FindFirstObjectByType<panelInfo>().ShowTooltip(tooltipMessage);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        FindFirstObjectByType<panelInfo>().HideTooltip();
    }
}