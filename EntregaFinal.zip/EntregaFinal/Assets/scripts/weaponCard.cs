using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class weaponCard : MonoBehaviour
{
    //public Image icon;
    public TMP_Text weaponNameText;
    public TMP_Text damage;
    public TMP_Text price;
    public Button buyButton;

    private weaponDataUI currentData;
    public TMP_FontAsset customFont;
    public void Setup(weaponDataUI data)
    {
        currentData = data;

        //icon.sprite = data.weaponIcon;

        weaponNameText.font = customFont;
        damage.font = customFont;
        price.font = customFont;

        weaponNameText.text = data.weaponName;
        damage.text = "Damage: " + data.damage;
        price.text = "Price: " + data.price;

        buyButton.onClick.RemoveAllListeners();
        buyButton.onClick.AddListener(() => BuyWeapon());
    }

    private void BuyWeapon()
    {
        int currentCoins = gameManager.Instance.coinsCollected;
        if (currentCoins<currentData.price)
        {
            Debug.Log("No tienes suficiente dinero.");
            return;
        }
        Debug.Log("Comprado: " + currentData.weaponName);
        bool isInventoryFull = gameManager.Instance.EquipWeapon(currentData.weaponPrefab, currentData.price);
        if (!isInventoryFull)
        {
            transform.parent.gameObject.SetActive(false);
        }
        else
        {
            Debug.Log("No se pudo comprar el arma: inventario lleno.");
        }
    }
}