using UnityEngine;

public class cameraFollow : MonoBehaviour
{

    public Transform target; // Jugador
    public Vector3 offset = new Vector3(0, 0, -20);
    public float smoothTime = 0.2f;

    //Limites de la camara
    private float mapMinX = -2.5f;
    private float mapMaxX = 2.3f;
    private float mapMinY = -4.8f;
    private float mapMaxY = 4.8f;




    private Vector3 velocity = Vector3.zero;

    void LateUpdate()
    {
        if (target == null)
            return;


        Vector3 targetPosition = target.position + offset;


        // Limitar la posici�n deseada de la c�mara
        targetPosition.x = Mathf.Clamp(targetPosition.x, mapMinX, mapMaxX);
        targetPosition.y = Mathf.Clamp(targetPosition.y, mapMinY, mapMaxY);

        transform.position = Vector3.SmoothDamp(transform.position, targetPosition, ref velocity, smoothTime);
    }
}
