using System;
using System.Collections.Generic;
using UnityEngine;

public class weaponsOrbit : MonoBehaviour
{
    public Transform player;  // El jugador alrededor del cual orbita la arma
    public float orbitRadius = 2f;  // Radio de la �rbita
    public float orbitSpeed = 50f;  // Velocidad de la �rbita (grados por segundo)
    public float angleOffset = 0f;  // Desfase angular para separar las armas

    private float angle;  // �ngulo actual de la �rbita

    void Start()
    {
        GameObject foundPlayer = GameObject.FindWithTag("Player");
        if (foundPlayer != null)
        {
            player = foundPlayer.transform;
        }
    }

    void Update()
    {
        if (player == null)
            return;

        float radians = angleOffset * Mathf.Deg2Rad;
        Vector2 offset = new Vector2(Mathf.Cos(radians), Mathf.Sin(radians)) * orbitRadius;
        transform.position = (Vector2)player.transform.position + offset;
    }
}