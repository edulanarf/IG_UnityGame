using System;
using UnityEngine;

public class coin : MonoBehaviour
{
    private Transform player;
    private bool attracted = false;

    void Start()
    {
        player = GameObject.FindWithTag("Player").transform;
    }

    // Update is called once per frame
    void Update()
    {
        if (attracted)
        {
            Vector3 direction = (player.position - transform.position).normalized;
            transform.position += direction * 10f * Time.deltaTime; //10f es la velocidad a la que se recoge la coin
        }
    }

    public void Attract()
    {
        attracted = true;
    }

    void OnTriggerEnter2D(Collider2D other) //Trigger ya que la moneda no queremos que tenga fisica
    {
        if (other.gameObject.CompareTag("Player"))
        {
            gameManager.Instance.AddCoin();
            Destroy(gameObject);
        }
    }
}