using System;
using UnityEngine;
using UnityEngine.UI;

public class hpBar : MonoBehaviour
{

    public Image hpBarImage;

    void Update()
    {
        hpBarImage.fillAmount = Mathf.Clamp((float)gameManager.Instance.currentHp / gameManager.Instance.maxHp, 0, 1);
    }
}
