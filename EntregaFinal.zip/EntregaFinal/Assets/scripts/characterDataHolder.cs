using UnityEngine;

public class characterDataHolder : MonoBehaviour
{
    public static GameObject selectedCharacterPrefab;
}
