using UnityEngine;

public class rangedWeapons : MonoBehaviour
{
    private Transform closestEnemy;
    private float fireCooldown;
    public int attackSpeed;


    public weaponStats weaponData;


    private void Start()
    {
        weaponData = GetComponent<weaponStats>();

    }
    void Update()
    {
        attackSpeed = gameManager.Instance.attackSpeed;
        weaponData.fireCooldown -= Time.deltaTime;
        closestEnemy = null;
        FindClosestEnemy();

        if (closestEnemy == null)
        {
            transform.rotation = Quaternion.identity;
            transform.localScale = new Vector3(1, 1, 1);
        }

        if (closestEnemy != null && weaponData.fireCooldown <= 0f)
        {
            Vector3 direction = closestEnemy.position - transform.position;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.Euler(0, 0, angle);

            if (direction.x < 0)
                transform.localScale = new Vector3(1, -1, 1);
            else
                transform.localScale = new Vector3(1, 1, 1);

            FireEnemy();
            float modifier = 1f + (attackSpeed / 100f);
            weaponData.fireCooldown = weaponData.fireRate / modifier;
        }
    }


    private void FindClosestEnemy()
    {
        Collider2D[] enemies = Physics2D.OverlapCircleAll(transform.position, weaponData.range + gameManager.Instance.playerRange); //Encontrar a los enemigos dentro del rango y meterlos en una lista
        float closestDistance = Mathf.Infinity;

        foreach (Collider2D enemy in enemies)
        {
            if (!enemy.gameObject.CompareTag("Enemy"))
            {
                continue;
            }

            if (enemy.gameObject.CompareTag("Enemy"))
            {
                float distanceToEnemy = Vector2.Distance(transform.position, enemy.transform.position);
                if (distanceToEnemy < closestDistance)
                {
                    closestEnemy = enemy.transform;
                    closestDistance = distanceToEnemy;
                }
            }
        }
    }

    private void FireEnemy()
    {
        if (weaponData.weaponBehavior != null)
        {
            weaponData.weaponBehavior.Fire(transform, closestEnemy, weaponData);
        }
    }
}
