using UnityEngine;

public interface IWeaponBehavior
{
    void Fire(Transform shooter, Transform target, weaponStats stats);
}