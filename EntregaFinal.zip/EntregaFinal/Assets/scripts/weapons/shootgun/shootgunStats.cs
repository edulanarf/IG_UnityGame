using UnityEngine;

public class shootgunStats : weaponStats
{
    public void Awake()
    {
        range = 1f; //Si se cambia, cambiar tamb en shootgunBullet (rango de perdigones)
        fireCooldown = 0f;
        fireRate = 2f;
        weaponDamage = 50;
        type = weaponType.range;

        weaponBehavior = gameObject.AddComponent<shootgunLogic>();
    }
}
