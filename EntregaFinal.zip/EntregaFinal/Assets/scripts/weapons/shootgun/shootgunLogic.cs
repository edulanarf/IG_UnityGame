using UnityEngine;

public class shootgunLogic : MonoBehaviour, IWeaponBehavior
{
    public int pellets = 5;
    public float spreadAngle = 30f;

    public void Fire(Transform shooter, Transform target, weaponStats stats)
    {
        Vector2 baseDirection = (target.position - shooter.position).normalized;
        float baseAngle = Mathf.Atan2(baseDirection.y, baseDirection.x) * Mathf.Rad2Deg;

        for (int i = 0; i < pellets; i++)
        {
            float angleOffset = Random.Range(-spreadAngle / 2f, spreadAngle / 2f);
            float angle = baseAngle + angleOffset;

            Vector2 direction = new Vector2(Mathf.Cos(angle * Mathf.Deg2Rad), Mathf.Sin(angle * Mathf.Deg2Rad));

            GameObject bullet = Instantiate(stats.bulletPrefab, shooter.position, Quaternion.Euler(0, 0, angle));

            IProjectile projectile = bullet.GetComponent<IProjectile>();
            projectile.SetDirection(direction);
            projectile.SetTarget(null, stats.weaponDamage); // No hay un �nico target, pero se pasa el da�o
        }
    }
}