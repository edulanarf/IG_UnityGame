using UnityEngine;

public class shootgunBullet : MonoBehaviour, IProjectile
{
    private Vector2 direction;
    public float speed = 10f;
    public int damage = 50;
    private float maxDistance = 1f;
    private Vector2 startPosition;

    public void SetDirection(Vector2 dir)
    {
        direction = dir.normalized;
    }

    public void SetTarget(Transform enemy, int dmg)
    {
        damage = dmg;
        startPosition = transform.position;
    }

    void Update()
    {
        // Movimiento lineal
        transform.position += (Vector3)(direction * speed * Time.deltaTime);

        // Comprobar distancia m�xima
        float playerBonus = gameManager.Instance.playerRange;
        float weaponRange = gameObject.GetComponentInParent<weaponStats>()?.range ?? 1f;
        maxDistance = weaponRange + playerBonus;
        if (Vector2.Distance(transform.position, startPosition) >= maxDistance)
        {
            Destroy(gameObject);
            return;
        }

        // Comprobar colisi�n con enemigos (mejor usar capa de enemigos para rendimiento)
        Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, 0.1f);
        foreach (Collider2D hit in hits)
        {
            if (hit.CompareTag("Enemy"))
            {
                enemy e = hit.GetComponent<enemy>();
                if (e != null)
                {
                    int rangeDamage = gameManager.Instance.rangeDamage;
                    e.damageEnemy(damage + rangeDamage);
                }
                Destroy(gameObject); // Destruye la bala al impactar
                break;
            }
        }
    }

    // Visualizaci�n opcional del alcance
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawLine(startPosition, startPosition + direction * maxDistance);
    }
}