using UnityEngine;

public class weaponStats : MonoBehaviour
{
    public float range;
    public float fireCooldown;
    public float fireRate;
    public int weaponDamage;
    public weaponType type;
    public GameObject bulletPrefab;

    public IWeaponBehavior weaponBehavior;
}

public enum weaponType
{
    melee,
    range
}
