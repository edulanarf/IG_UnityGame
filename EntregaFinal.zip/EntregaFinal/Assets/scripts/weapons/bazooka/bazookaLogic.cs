using UnityEngine;

public class bazookaLogic : MonoBehaviour, IWeaponBehavior
{
    public void Fire(Transform shooter, Transform target, weaponStats stats)
    {
        if (target == null) return;

        Vector3 spawnPosition = shooter.position;
        Vector2 direction = (target.position - spawnPosition).normalized;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        GameObject bullet = Instantiate(stats.bulletPrefab, spawnPosition, Quaternion.Euler(0, 0, angle));

        bazookaBullet projectile = bullet.GetComponent<bazookaBullet>();
        if (projectile != null)
        {
            projectile.SetTarget(target, stats.weaponDamage);
        }
    }
}
