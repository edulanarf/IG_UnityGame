using UnityEngine;

public class bazookaStats : weaponStats
{
    public void Awake()
    {
        range = 3f;
        fireCooldown = 0f;
        fireRate = 3f;
        weaponDamage = 100;
        type = weaponType.range;

        weaponBehavior = gameObject.AddComponent<bazookaLogic>();
    }
}
