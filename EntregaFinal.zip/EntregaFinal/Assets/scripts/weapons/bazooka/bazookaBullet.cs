using UnityEngine;

public class bazookaBullet : MonoBehaviour, IProjectile
{
    public float speed = 5f;
    public int damage = 100;
    private Transform target;

    public float explosionRadius = 1f; // Radio de da�o en �rea
    public GameObject explosionEffect; // Opcional: efecto visual de explosi�n

    public void SetDirection(Vector2 dir) { }

    public void SetTarget(Transform enemy, int dmg)
    {
        target = enemy;
        damage = dmg;
    }

    void Update()
    {
        if (target == null)
        {
            Explode();
            return;
        }

        transform.position = Vector2.MoveTowards(transform.position, target.position, speed * Time.deltaTime);

        if (Vector2.Distance(transform.position, target.position) < 0.1f)
        {
            Explode();
        }
    }

    private void Explode()
    {
        // Efecto visual
        if (explosionEffect != null)
        {
            Instantiate(explosionEffect, transform.position, Quaternion.identity);
        }

        // Da�o en �rea
        Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, explosionRadius);

        foreach (Collider2D hit in hits)
        {
            if (hit.CompareTag("Enemy"))
            {
                enemy e = hit.GetComponent<enemy>();
                if (e != null)
                {
                    int rangeDamage = gameManager.Instance.rangeDamage;
                    e.damageEnemy(damage + rangeDamage);
                }
            }
        }

        Destroy(gameObject);
    }

    // Solo para visualizar en editor el �rea de explosi�n
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, explosionRadius);
    }
}
