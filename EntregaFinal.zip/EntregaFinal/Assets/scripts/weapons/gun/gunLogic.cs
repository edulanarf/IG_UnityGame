using UnityEngine;

public class gunLogic : MonoBehaviour, IWeaponBehavior
{
    public void Fire(Transform shooter, Transform target, weaponStats stats)
    {
        if (target == null) return;

        Vector3 spawnPosition = shooter.position;
        Vector2 direction = (target.position - spawnPosition).normalized;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        GameObject bullet = Instantiate(stats.bulletPrefab, spawnPosition, Quaternion.Euler(0, 0, angle));

        gunBullet projectile = bullet.GetComponent<gunBullet>();
        if (projectile != null)
        {
            projectile.SetDirection(direction);
            projectile.SetTarget(target, stats.weaponDamage);
        }
    }
}
