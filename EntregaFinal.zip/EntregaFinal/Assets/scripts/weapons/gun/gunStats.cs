using UnityEngine;

public class gunStats : weaponStats
{
    public void Awake()
    {
        range = 5f;
        fireCooldown = 0f;
        fireRate = 1f;
        weaponDamage = 30;
        type= weaponType.range;
        weaponBehavior = gameObject.AddComponent<gunLogic>();
    }
}
