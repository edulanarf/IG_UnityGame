using UnityEngine;

public class gunBullet : MonoBehaviour, IProjectile
{
    private Vector2 direction;
    public float speed = 45f;
    public int damage = 30;
    private Transform target;

    public void SetDirection(Vector2 dir)
    {
        direction = dir.normalized;
    }

    public void SetTarget(Transform enemy, int dmg)
    {
        target = enemy;
        damage = dmg;
    }

    void Update()
    {
        if (target == null)
        {
            Destroy(gameObject);
            return;
        }

        transform.position += (Vector3)direction * speed * Time.deltaTime;

        // Si llega al enemigo
        if (Vector2.Distance(transform.position, target.position) < 0.1f)
        {
            enemy enemyScript = target.GetComponent<enemy>();
            if (enemyScript != null)
            {
                int rangeDamage = gameManager.Instance.rangeDamage;
                enemyScript.damageEnemy(damage + rangeDamage);
            }
            Destroy(gameObject);
        }
    }
}
