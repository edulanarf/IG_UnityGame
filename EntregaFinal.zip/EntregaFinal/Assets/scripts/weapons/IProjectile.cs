using UnityEngine;

public interface IProjectile
{
    void SetTarget(Transform target, int damage);
    void SetDirection(Vector2 direction);
}