using UnityEditor.U2D.Animation;
using UnityEngine;
using UnityEngine.SceneManagement;

public class characterSelector : MonoBehaviour
{
    public GameObject characterPrefab;

    public void SelectCharacter()
    {
        characterDataHolder.selectedCharacterPrefab = characterPrefab;
        SceneManager.LoadScene("chooseWeapon");
    }

}
