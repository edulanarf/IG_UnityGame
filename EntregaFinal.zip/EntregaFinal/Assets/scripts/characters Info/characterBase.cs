using UnityEngine;

public class characterBase : MonoBehaviour
{
    public string characterName;
    public int maxHealth;
    public int healthRecovery; //En %
    public int lifeSteal;//En %
    public int damage;//En %
    public int meleeDamage;
    public int rangeDamage;
    public int elementalDamage;
    public int attackSpeed; //En %
    public int crit;//En %
    public float range;
    public int agility;
    public float speed;
}
