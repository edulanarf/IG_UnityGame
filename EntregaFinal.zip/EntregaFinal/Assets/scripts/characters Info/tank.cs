using UnityEngine;

public class tank : characterBase
{
    private void Awake()
    {
        characterName = "Tanque";
        maxHealth = 200;
        healthRecovery = 1;
        lifeSteal = 0;
        damage = 0;
        meleeDamage = 0;
        rangeDamage = 0;
        elementalDamage = 0;
        attackSpeed = 0;
        crit = 0;
        range = 0;
        agility = 0;
        speed = 5f;
    }
}
