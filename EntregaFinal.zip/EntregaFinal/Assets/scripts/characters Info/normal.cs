using UnityEngine;

public class normal : characterBase
{
    private void Awake()
    {
        characterName = "Normal";
        maxHealth = 50;
        healthRecovery = 1;
        lifeSteal = 0;
        damage = 0;
        meleeDamage = 0;
        rangeDamage = 0;
        elementalDamage = 0;
        attackSpeed = 0;
        crit = 0;
        range = 0;
        agility = 0;
        speed = 3f;

    }
}
   
