using System;
using UnityEngine;

public class coinCollector : MonoBehaviour
{
    public float range = 1f;
    public Transform player;
    void Start()
    {
        player = GameObject.FindWithTag("Player").transform;
    }

    void Update()
    {

        Collider2D[] coins = Physics2D.OverlapCircleAll(transform.position, range);
        foreach (Collider2D coinCollider in coins)
        {
            if (!coinCollider.gameObject.CompareTag("coin"))
            {
                continue;
            }
            else
            {
                coin coin = coinCollider.GetComponent<coin>();
                if (coin != null)
                {
                    coin.Attract();
                }
            }
        }
    }
}
