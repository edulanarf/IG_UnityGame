﻿using System.Collections;
using TMPro;
using UnityEngine;

public class wavesHandler : MonoBehaviour
{
    public int currentWave = 0;
    public float waveDuration = 30f;
    public float breakDuration = 10f;
    public GameObject shopCanvas;
    public bool isWaveActive = false;
    public TextMeshProUGUI textoTiendaOleada;
    public TextMeshProUGUI hpText;
    public TextMeshProUGUI hpRecoveryText;
    public TextMeshProUGUI lifeStealText;
    public TextMeshProUGUI damageText;
    public TextMeshProUGUI meleeDamageText;
    public TextMeshProUGUI rangeDamageText;
    public TextMeshProUGUI elementalText;
    public TextMeshProUGUI attackSpeedText;
    public TextMeshProUGUI critText;
    public TextMeshProUGUI rangeText;
    public TextMeshProUGUI agilityText;
    public TextMeshProUGUI speedText;

    private enemySpawner spawner;
    private shopManager shopManager;

    void Start()
    {
        shopManager = FindFirstObjectByType<shopManager>();
        spawner = FindFirstObjectByType<enemySpawner>();
        StartCoroutine(HandleWaves());
    }

    IEnumerator HandleWaves()
    {
        while (true)
        {
            shopCanvas.SetActive(false);
            currentWave++;

            isWaveActive = true;
            spawner.EnableSpawning(currentWave);

            yield return new WaitForSeconds(waveDuration);

            spawner.DisableSpawning();
            spawner.DestroyAllEnemies();
            isWaveActive = false;


            shopCanvas.SetActive(true);
            textoTiendaOleada.text = "Shop (Round " + currentWave + ")";
            updateText();
            shopManager.OpenShop();

            isWaitingForNextWave = true;
            while (isWaitingForNextWave)
            {
                yield return null;
            }
        }
    }

    void updateText()
    {
        hpText.text = gameManager.Instance.maxHp.ToString();
        hpRecoveryText.text = gameManager.Instance.recoveryHp.ToString();
        lifeStealText.text = gameManager.Instance.lifeSteal.ToString();
        damageText.text = gameManager.Instance.damagePercent.ToString();
        meleeDamageText.text = "0"; //cambiar
        rangeDamageText.text = gameManager.Instance.rangeDamage.ToString();
        elementalText.text = "0";//cambiar
        attackSpeedText.text = gameManager.Instance.attackSpeed.ToString();
        critText.text = gameManager.Instance.critProb.ToString();
        rangeText.text = gameManager.Instance.playerRange.ToString();
        agilityText.text = "0";//cambiar
        speedText.text = gameManager.Instance.speed.ToString();
    }

    private bool isWaitingForNextWave = false;
    public void StartNextWave()
    {
        isWaitingForNextWave = false;
        shopCanvas.SetActive(false);
    }

}
