using UnityEngine;

public class weaponDataUI : MonoBehaviour
{
    public string weaponName;
    //public Sprite weaponIcon;
    public string damage;
    public int price;
    public GameObject weaponPrefab;

}
