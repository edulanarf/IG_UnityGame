using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using static UnityEngine.Rendering.DebugUI;

public class gameManager : MonoBehaviour
{
    public int coinsCollected = 0;
    public int maxHp;
    public int currentHp;
    public float speed;
    public int recoveryHp;
    public int lifeSteal;
    public int damagePercent;
    public int rangeDamage;
    public int attackSpeed;
    public int critProb;
    public float playerRange;
    public static gameManager Instance;
    public List<GameObject> equippedWeapons = new List<GameObject>();
    public int maxWeapons = 6;

    //Prueba
    public GameObject gunPrefab;
    public GameObject bazookaPrefab;

    //Texto de monedas
    public TextMeshProUGUI monedas;
    public TextMeshProUGUI monedasTienda;

    void Awake()
    {
        if(Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        if (characterDataHolder.selectedCharacterPrefab != null)    
        {   
            

            GameObject playerGO = Instantiate(characterDataHolder.selectedCharacterPrefab);
            characterBase characterStats = playerGO.GetComponent<characterBase>();
            player playerScript = playerGO.AddComponent<player>();

            //Cargar stats en gameManager
            maxHp = characterStats.maxHealth;
            currentHp = maxHp;
            speed = characterStats.speed;
            recoveryHp = characterStats.healthRecovery;
            lifeSteal = characterStats.lifeSteal;
            damagePercent = characterStats.damage;
            rangeDamage = characterStats.rangeDamage;
            attackSpeed = characterStats.attackSpeed;
            critProb = characterStats.crit;
            playerRange = characterStats.range;
            //Cargar stats en player
            playerScript.speed = characterStats.speed;
            playerScript.maxHealth = characterStats.maxHealth;
            playerScript.characterName = characterStats.characterName;
            //Cargar player en camera
            cameraFollow camera = Camera.main.GetComponent<cameraFollow>();
            camera.target = playerGO.transform;
            //Cargar player en enemySpawner
            enemySpawner enemySpawner = FindFirstObjectByType<enemySpawner>();
            enemySpawner.player = playerGO.transform;
            //Empieza a regenerar vida
            StartCoroutine(AutoRecoverHealth());

            //Equipa arma elegida
            GameObject weaponSelected = weaponDataHolder.selectedWeaponPrefab;
            EquipWeapon(weaponSelected, 0);
        }
    }

    public void AddCoin()
    {
        coinsCollected++;
        monedas.text = $"<sprite=0> {coinsCollected.ToString()}";
        monedasTienda.text = $"<sprite=0> {coinsCollected.ToString()}";
    }

    public void damage(int pointsDamage)
    {
        currentHp -= pointsDamage;
        if(currentHp < 0) { SceneManager.LoadScene("Menu"); }
    }

    public void healthRecovery(int value)
    {
        int recoveryAmount = Mathf.CeilToInt(maxHp * (value / 100f));
        currentHp += recoveryAmount;
        currentHp = Mathf.Min(currentHp, maxHp);
    }


    private IEnumerator AutoRecoverHealth()
    {
        while (true)
        {
            yield return new WaitForSeconds(5f);
            healthRecovery(recoveryHp);
        }
    }

    public void healLifeSteal(int damageDone)
    {
        int healingAmount = Mathf.CeilToInt(damageDone * (lifeSteal / 100f));
        currentHp += healingAmount;
        currentHp = Mathf.Min(currentHp, maxHp);
    }




    public bool EquipWeapon(GameObject weaponPrefab, int price)
    {
        if (equippedWeapons.Count >= maxWeapons)
        {
            Debug.Log("Inventario de armas lleno");
            return true;
        }

        // Instanciar el arma
        GameObject weapon = Instantiate(weaponPrefab, transform.position, Quaternion.identity);

        weaponsOrbit orbit = weapon.GetComponent<weaponsOrbit>();
        if (orbit != null)
        {
            orbit.player = GameObject.FindWithTag("Player").transform.Find("orbitCenter");
            orbit.orbitRadius = 1f;
            orbit.orbitSpeed = 25f;
            orbit.angleOffset = 360f / (equippedWeapons.Count + 1) * equippedWeapons.Count;
        }

        // A�adir al inventario y restar dinero
        coinsCollected -= price;
        monedas.text = $"<sprite=0> {coinsCollected.ToString()}";
        monedasTienda.text = $"<sprite=0> {coinsCollected.ToString()}";
        equippedWeapons.Add(weapon);

        RecalculateOrbitOffsets(equippedWeapons);
        return false;
    }

    public void RemoveWeapon(GameObject weapon)
    {
        weaponsOrbit orbit = weapon.GetComponent<weaponsOrbit>();
        if (equippedWeapons.Contains(weapon))
        {
            equippedWeapons.Remove(weapon);
            Destroy(weapon);
            RecalculateOrbitOffsets(equippedWeapons);
        }
    }

    public void RecalculateOrbitOffsets(List<GameObject> equippedWeapons)
    {
        int total = equippedWeapons.Count;
        for (int i = 0; i < total; i++)
        {
            weaponsOrbit orbit = equippedWeapons[i].GetComponent<weaponsOrbit>();
            if (orbit != null)
            {
                orbit.angleOffset = 360f / total * i;
            }
        }
    }
}
