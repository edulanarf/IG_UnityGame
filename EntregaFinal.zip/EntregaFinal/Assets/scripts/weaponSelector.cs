using UnityEngine;
using UnityEngine.SceneManagement;

public class weaponSelector : MonoBehaviour
{
    public GameObject weaponPrefab;

    public void SelectWeapon()
    {
        weaponDataHolder.selectedWeaponPrefab = weaponPrefab;
        SceneManager.LoadScene("game");
    }

}
