using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

public class buttonTextColor : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public Image background;
    public TextMeshProUGUI text;

    [Header("Colors")]
    public Color normalBG = Color.black;
    public Color hoverBG = Color.white;

    public Color normalText = Color.white;
    public Color hoverText = Color.black;

    void Start()
    {
        // Estado inicial
        background.color = normalBG;
        text.color = normalText;
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        background.color = hoverBG;
        text.color = hoverText;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        background.color = normalBG;
        text.color = normalText;
    }
}