using UnityEngine;
using UnityEngine.UI;

public class player : MonoBehaviour
{
    private Rigidbody2D rigidBody;
    public string characterName;
    public int maxHealth;
    public float speed;

    void Start()
    {
        rigidBody = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        float moveHorizontal = Input.GetAxisRaw("Horizontal");

        // Girar jugador
        if (moveHorizontal > 0)
            transform.localScale = new Vector3(-2, 2, 1);
        else if (moveHorizontal < 0)
            transform.localScale = new Vector3(2, 2, 1);
    }

    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxisRaw("Horizontal");
        float moveVertical = Input.GetAxisRaw("Vertical");

        Vector2 input = new Vector2(moveHorizontal, moveVertical);

        gameManager.Instance.speed = speed;
        Vector2 movement = input.normalized * speed;

        rigidBody.linearVelocity = movement;
    }

}
