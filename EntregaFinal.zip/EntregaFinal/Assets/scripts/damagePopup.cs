using TMPro;
using UnityEngine;

public class damagePopup : MonoBehaviour
{
    public TextMeshProUGUI textMesh;
    public float moveSpeed = 1f;
    public float fadeSpeed = 2f;
    public float lifetime = 1f;

    private Color textColor;
    private float timer;

    public void Setup(int damageAmount, bool isCrit)
    {
        textMesh.text = damageAmount.ToString();
        textColor = isCrit?Color.red : textMesh.color;
        textMesh.color = textColor;
    }

    void Update()
    {
        transform.position += new Vector3(0, moveSpeed * Time.deltaTime, 0);

        timer += Time.deltaTime;
        if (timer >= lifetime)
        {
            textColor.a -= fadeSpeed * Time.deltaTime;
            textMesh.color = textColor;

            if (textColor.a <= 0f)
            {
                Destroy(gameObject);
            }
        }
    }
}
