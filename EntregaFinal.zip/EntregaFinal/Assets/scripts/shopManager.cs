using System.Collections.Generic;
using UnityEngine;

public class shopManager : MonoBehaviour
{
    public List<GameObject> weaponUIDatas;
    public List<Transform> weaponSlots;
    public GameObject weaponCardPrefab;
    public int numberOfWeaponsToShow = 4;
    
    public void OpenShop()
    {
        ClearShop();
        for (int i = 0; i < weaponSlots.Count; i++)
        {
            int rand = Random.Range(0, weaponUIDatas.Count);
            GameObject dataGO = weaponUIDatas[rand];
            weaponDataUI data = dataGO.GetComponent<weaponDataUI>();

            GameObject card = Instantiate(weaponCardPrefab, weaponSlots[i]);
            RectTransform cardRect = card.GetComponent<RectTransform>();

            cardRect.localPosition = Vector3.zero;

            card.GetComponent<weaponCard>().Setup(data);
            weaponSlots[i].gameObject.SetActive(true);
        }
    }

    void ClearShop()
    {
        foreach (Transform slot in weaponSlots)
        {
            foreach (Transform child in slot)
            {
                Destroy(child.gameObject);
            }
        }
    }
    
}
