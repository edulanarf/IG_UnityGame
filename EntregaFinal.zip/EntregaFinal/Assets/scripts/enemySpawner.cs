using UnityEngine;

public class enemySpawner : MonoBehaviour
{
    public GameObject enemyPrefab;       
    public Transform player;             
    public float spawnDistanceMin = 5f;  
    public float spawnDistanceMax = 10f; 

    public float mapMinX = -8.5f;
    public float mapMaxX = 8.5f;
    public float mapMinY = -6.4f;
    public float mapMaxY = 6.4f;

    public int enemiesPerSpawn = 3;
    public float spawnRadius = 3f;

    private float timer;
    public float spawnInterval = 5f;

    private bool canSpawn = false; 

    void Update()
    {
        if (!canSpawn) return;

        timer += Time.deltaTime;

        if (timer >= spawnInterval)
        {
            SpawnEnemyPack();
            timer = 0f;
        }
    }

    void SpawnEnemyPack()
    {

        Vector2 spawnCenter = GetRandomPositionFarFromPlayer();

        Instantiate(enemyPrefab, spawnCenter, Quaternion.identity);

        for (int i = 1; i < enemiesPerSpawn; i++)
        {
            Vector2 randomOffset = Random.insideUnitCircle.normalized * Random.Range(1f, spawnRadius);
            Vector2 spawnPos = spawnCenter + randomOffset;

            spawnPos.x = Mathf.Clamp(spawnPos.x, mapMinX, mapMaxX);
            spawnPos.y = Mathf.Clamp(spawnPos.y, mapMinY, mapMaxY);

            Instantiate(enemyPrefab, spawnPos, Quaternion.identity);
        }
    }

    Vector2 GetRandomPositionFarFromPlayer()
    {
        Vector2 pos;
        float distance;
        do
        {
            pos = new Vector2(Random.Range(mapMinX, mapMaxX), Random.Range(mapMinY, mapMaxY));
            distance = Vector2.Distance(pos, player.position);
        }
        while (distance < spawnDistanceMin || distance > spawnDistanceMax);

        return pos;
    }

    public void EnableSpawning(int waveNumber)
    {
        canSpawn = true;
        enemiesPerSpawn = Mathf.Clamp(1 + waveNumber / 2, 1, 10);
        spawnInterval = Mathf.Max(1f, 5f - (waveNumber * 0.3f));
    }

    public void DisableSpawning()
    {
        canSpawn = false;
    }

    public void DestroyAllEnemies()
    {
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");

        foreach (GameObject enemy in enemies)
        {
            Destroy(enemy);
        }
    }
}
